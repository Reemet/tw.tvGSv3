import React from 'react';

const Spinner = () => {
    return (
        <div>
            <span className="loader loader-quart" />
        </div>
    );
};
export default Spinner;